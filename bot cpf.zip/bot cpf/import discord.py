
import discord
from discord.ext import commands

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"✅ Le bot est connecté en tant que {bot.CPF}")

@bot.command()
async def ping(ctx):
    await ctx.send("Pong ! 🏓")

bot.run("MTM4NDQ3ODk5ODYyMDQwOTg5OQ.GPAz54.GDmSaIgFuNyRbgpUBSm6dYE9uEAu-cm4bg1y3c")  
